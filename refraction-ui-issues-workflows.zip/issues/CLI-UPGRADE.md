---
id: CLI-UPGRADE
track: cli
depends_on: ['CLI-ADD']
size: M
labels: [feat]
---

## Summary
upgrade command using version headers

## Acceptance Criteria
- Reads header
- Three way diff
- Applies patch

## Tasks
- Version parse
- Diff3
- Tests

## Notes

