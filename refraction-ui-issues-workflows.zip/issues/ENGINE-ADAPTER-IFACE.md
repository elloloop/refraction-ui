---
id: ENGINE-ADAPTER-IFACE
track: engines
depends_on: ['COMP-API-CONTRACT']
size: S
labels: [feat]
---

## Summary
EngineAdapter interface and contract tests

## Acceptance Criteria
- Interface exported
- Contract test harness

## Tasks
- Interface file
- Tests

## Notes

