---
id: ENGINE-RADIX
track: engines
depends_on: ['ENGINE-ADAPTER-IFACE','COMP-DIALOG']
size: M
labels: [feat]
---

## Summary
Radix adapter for Dialog (plus sample others)

## Acceptance Criteria
- Swap engine via provider
- Tests parity

## Tasks
- Map props
- Tests

## Notes

