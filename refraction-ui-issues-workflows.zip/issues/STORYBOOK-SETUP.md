---
id: STORYBOOK-SETUP
track: docs
depends_on: ['COMP-BUTTON']
size: S
labels: [docs,feat]
---

## Summary
Storybook 8 config and test runner

## Acceptance Criteria
- Stories render
- Axe test runner works

## Tasks
- Config
- Scripts

## Notes
ADR 0002
