---
id: COMP-API-CONTRACT
track: components
depends_on: ['DOCS-FREEZE']
size: S
labels: [feat,docs]
---

## Summary
Canon prop types for core components

## Acceptance Criteria
- Types exported
- Used in templates

## Tasks
- Write types
- Export
- Tests compile

## Notes

