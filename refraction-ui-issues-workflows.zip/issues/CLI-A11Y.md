---
id: CLI-A11Y
track: cli
depends_on: ['STORYBOOK-SETUP']
size: S
labels: [a11y,feat]
---

## Summary
a11y command using axe-core

## Acceptance Criteria
- Strict mode fails on violations
- JSON report

## Tasks
- Implement runner
- Tests

## Notes

