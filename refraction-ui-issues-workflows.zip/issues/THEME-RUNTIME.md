---
id: THEME-RUNTIME
track: tokens
depends_on: ['TOKENS-BUILD']
size: S
labels: [feat]
---

## Summary
ThemeProvider and useTheme hook

## Acceptance Criteria
- Runtime switch without flash
- Persists selection

## Tasks
- Provider
- Hook
- Example

## Notes

