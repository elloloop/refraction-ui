---
id: CLI-TOKENS
track: cli
depends_on: ['TOKENS-SCHEMA','TOKENS-BUILD']
size: S
labels: [feat]
---

## Summary
tokens import/build commands

## Acceptance Criteria
- Valid JSON in
- CSS vars out
- Tests

## Tasks
- Implement import
- Build
- Tests

## Notes

