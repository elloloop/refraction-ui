---
id: RELEASE-PIPELINE
track: release
depends_on: ['CI-SETUP']
size: S
labels: [chore]
---

## Summary
Changesets release workflow

## Acceptance Criteria
- Release PR auto
- Publish works

## Tasks
- Config changesets
- Action

## Notes

