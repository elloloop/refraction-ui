---
id: DOCS-SITE
track: docs
depends_on: ['STORYBOOK-SETUP','CLI-INIT']
size: M
labels: [docs]
---

## Summary
Guide site with token playground

## Acceptance Criteria
- Guides for getting started, theming, CLI, MCP
- Playground works

## Tasks
- Site setup
- Write pages
- Playground

## Notes

