#!/usr/bin/env node
// TODO: implement bundle size measurement using size-limit or rollup plugin.
// For now, always OK.
process.exit(0);
